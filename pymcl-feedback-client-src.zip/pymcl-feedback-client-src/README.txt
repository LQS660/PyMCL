﻿PyMCL 反馈系统 — 客户端源码

不含 feedback_hub 服务端，不含 exe。

上报地址（已写进 mclauncher/feedback_defaults.py）
  http://114.66.28.184:53611
  POST /api/v1/feedback
  POST /api/v1/heartbeat
  不要带 /api 前缀，不要填看板端口。

本包文件
  mclauncher/feedback_defaults.py   默认上报地址、分类
  mclauncher/feedback.py            同意、提交、心跳、崩溃上报
  mclauncher/sysinfo.py             本机配置采集
  app/pages/feedback_page.py        侧栏「反馈」页
  app/pages/crash_dialog.py         崩溃窗「发送给开发者」
  app/widgets.py                    prompt_feedback_consent 首次同意弹窗

启动器里其它接入点（文件仍在原工程，本包不整份拷贝）
  app/main_window.py     首次弹同意、退出停心跳
  app/pages/settings_page.py  允许上传 / 上报地址 / 心跳开关
  app/backend.py         submit_feedback / submit_crash_feedback
  bridge/api.py          同上，给 WinUI 桥
  mclauncher/config.py   feedback_url / consent / heartbeat
  main.py                CLI pymcl feedback
